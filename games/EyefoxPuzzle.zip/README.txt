You will need Python with pygame to launch the game.

Windows : Simply run it with the Python Launcher
Linux/Windows : python3 EyefoxPuzzle.pyz 
