You will need Python with pygame to launch the game.
To install pygame: pip install pygame

Windows : Simply run it with the Python Launcher
Linux/Windows : python3 EyefoxPuzzle.pyz 
